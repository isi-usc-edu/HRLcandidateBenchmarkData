from itertools import product
from collections import defaultdict

import numpy as np

import dirac_utils as du
from MajoranaOperator import MajoranaOperator





class QuarticFermion:

    def __init__(self, V, h=None, num_sites=None):
        """
        
        Represents an operator which can be written as a sum of 
        quartic and possibly quadratic terms; 


        H = sum_{p, q}  h_{pq} a^_p a_q    +    sum_{p, q, r, s} V_{pqrs} a^_p a_q a^_r a_s


        Note that this is always in "chemist notation" for the quartic term

        """

        self.V = V
        self.h = h
        self.num_sites = num_sites

    def __str__(self):
        return 'Quadratic part:\n' + str(self.h) + '\n\n' + 'Quartic part:\n' + str(self.V)

    def rotate_modes(self, U):
        """
        Implement a bouglibov transformation / orbital rotation
        given by the unitary matrix U

        """

        h, V = self.h, self.V

        g = None
        if h is not None:
            g = np.einsum('pq,pi,qj->ij', h, U.conjugate(), U)

        W = np.einsum('pqrs,pi,qj,rk,sl->ijkl', V, U.conjugate(), U, U.conjugate(), U)

        self.h = g
        self.V = W


    def diagonalize_quadratic_part(self):
        """
        Diagonalize the quadratic part.
        """
        if self.h is None:
            pass
        else:
            # The columns of U are the eigenvectors, meaning that
            # we have the diagonal form:          D = U @ h @ U^          
            _, U = np.linalg.eigh(self.h)
        
            self.rotate_modes(U)


    def make_purely_quartic(self):
        """
        Diagonalize the quadratic part and add it to the quartic part, 
        because fermionic number operators square to themselves:
        ( a^ a a^ a ) = (a^ a)
        """
        if self.h is None:
            pass
        else:           
            eigs, U = np.linalg.eigh(self.h)
            # The columns of U are the eigenvectors, meaning that
            # D = U @ h @ U^    is diagonal

            self.rotate_modes(U)
            W = self.V

            for i in np.nonzero(eigs)[0]:
                W[i][i][i][i] = W[i][i][i][i] + eigs[i]

            self.V = W
            self.h = None

    def double_factorization(self, purely_quartic=True):
        """
        
        """
        
        return_one_body_correction = False
        if self.h is not None:
            if purely_quartic:
                self.make_purely_quartic()
            else:
                return_one_body_correction = True

        N = self.num_sites
        N_sq = pow(N, 2)
        W = np.reshape(self.V, (N_sq, N_sq))
        lambs, g_vecs = np.linalg.eigh(W)

        gmats = []
        for g in g_vecs:
            g_mat = np.reshape(g, (N, N))
            gmats.append(g_mat)

        if return_one_body_correction:
            return self.h, lambs, gmats
        return lambs, gmats
        
    def to_majorana_operator(self, normal_ordered=True):
        """
        TODO: Document
        """
        h, V, N = self.h, self.V, self.num_sites

        majorana_data = defaultdict(lambda: 0)


        if h is not None:
            for i, j in zip(*np.nonzero(h)):
                for maj, phase in du.quadratic_majorana_from_dirac(i,j).items():
                    majorana_data[maj] = majorana_data[maj] + phase * h[i][j]


        for p, q, r, s in zip(*np.nonzero(V)):
            for maj, phase in du.quartic_majorana_from_dirac(p, q, r, s).items():
                majorana_data[maj] = majorana_data[maj] + phase * V[p][q][r][s]

        return MajoranaOperator(majorana_data, 2*N+1, normal_ordered=normal_ordered)


class CompletelyDelocalizedModel(QuarticFermion):

    def __init__(self, num_sites, J, h=None, G1=None, G2=None):
        """
        We're going to work on the **chemist's CDL** i.e.
        the coupling strength J will be between
        
        sum_{i,j}   J * a^_i a_j a^_j a_i

        """

        if G1 is not None:
            raise NotImplementedError
        if G2 is not None:
            raise NotImplementedError
        
        self.num_sites = num_sites
        self.J = J
        self.h = h


    def to_majorana_operator(self, normal_ordered=True):

        majorana_data = defaultdict(lambda: 0)

        N, J, h = self.num_sites, self.J, self.h

        if h is not None:
            for i, j in product(range(N), range(N)):
                for maj, phase in du.quadratic_majorana_from_dirac(i,j).items():
                    majorana_data[maj] = majorana_data[maj] + phase * h

        for i, j in product(range(N), range(N)):
            for maj, phase in du.quartic_majorana_from_dirac(i, j, j, i).items():
                majorana_data[maj] = majorana_data[maj] + phase * J



        return MajoranaOperator(majorana_data, 2*N+1, normal_ordered=normal_ordered)



def MO_from_unique_tuple(p, q, r, s):
    """
    Takes in the four parameters that uniquely determine an orbital integral. We always
    have the terms
    
    C * (   a^_p a_q a^_r a_s
        +   a^_p a_q a^_s a_r
        +   a^_q a_p a^_r a_s
        +   a^_q a_p a^_s a_r

        +   a^_r a_s a^_p a_q
        +   a^_r a_s a^_q a_p
        +   a^_s a_r a^_p a_q
        +   a^_s a_r a^_q a_p   )

    In the total Hamiltonian. This causes many cancellations when converted to the normal
    ordered Majorana representation, and we know ahead of time that this is going to look like;

    C/2 * ( -   c_p c'_q c_r c'_s
            +   c_p c'_q c'_r c_s
            +   c'_p c_q c_r c_s
            -   c'_p c_q c'_r c_s   )

    
    
    where we've assumed without loss of generality that p <= q <= r <= s

    """

    # In case they get passed incorrectly
    p, q = sorted([p, q])
    r, s = sorted([r, s])

    (p, q), (r, s) = sorted([(p, q), (r, s)])

    



if __name__ == "__false__":

    N = 8
    # digits = [(0, 2, 4, 6), (0, 4, 2, 6), (2, 4, 0, 6)]

    # digits = [(0, 0, 4, 6), (0, 4, 0, 6), (0, 4, 0, 6)]
    # digits = [(0, 2, 2, 6), (0, 2, 2, 6), (2, 2, 0, 6)]
    # digits = [(0, 2, 4, 4), (0, 4, 2, 4), (2, 4, 0, 4)]

    digits = [(0, 0, 4, 4,), (0, 4, 0, 4), (0, 4, 0, 4)]

    # digits = [(0, 0, 0, 6), (0, 0, 0, 6), (0, 0, 0, 6)]
    # digits = [(0, 2, 2, 2), (0, 2, 2, 2), (2, 2, 0, 2)]
    # digits = [(0, 0, 0, 2), (0, 2, 2, 2)]

    # digits = [(0, 0, 0, 0), (0, 0, 0, 0), (0, 0, 0, 0)]

    two_body = True
    one_body = False
    
    unique_MOs = []

    # p, q, r, s = 2, 4, 0, 6
    i, j = 0, 1


    for p, q, r, s in digits:

        h2_coeff = 1
        h1_coeff = 1

        V = np.zeros((N, N, N, N))
        h = None
        
        if two_body:

            V[p][q][r][s] = h2_coeff
            V[p][q][s][r] = h2_coeff
            V[q][p][r][s] = h2_coeff
            V[q][p][s][r] = h2_coeff

            V[r][s][p][q] = h2_coeff
            V[s][r][p][q] = h2_coeff
            V[r][s][q][p] = h2_coeff
            V[s][r][q][p] = h2_coeff


        if one_body:
            h = np.zeros((N, N))
        
            h[i][j] = h1_coeff
            h[j][i] = h1_coeff


        QF = QuarticFermion(V, h=h, num_sites=N)
        
        MO = QF.to_majorana_operator()

        unique_MOs.append(MO)

        print(f"( {p} {q} | {r} {s} )")
        print(MO)
        print('==============')

    MO1, MO2, MO3 = unique_MOs
    s1, s2, s3 = str(MO1), str(MO2), str(MO3)
    # print(s1, '\n\n', s2, '\n\n', s3, '\n\n')



    # from itertools import permutations
    # for p, q, r, s in permutations(digits[0]):

    #     # print(p, q, r, s)

    #     V = np.zeros((N, N, N, N))

    #     V[p][q][r][s] = h2_coeff
    #     V[p][q][s][r] = h2_coeff
    #     V[q][p][r][s] = h2_coeff
    #     V[q][p][s][r] = h2_coeff

    #     V[r][s][p][q] = h2_coeff
    #     V[s][r][p][q] = h2_coeff
    #     V[r][s][q][p] = h2_coeff
    #     V[s][r][q][p] = h2_coeff

    #     QF = QuarticFermion(V, num_sites=N)
        
    #     MO = QF.to_majorana_operator()
    #     s = str(MO)

    #     print(MO, '\n\n')
    #     print(s == s1)
    #     print(s == s2)
    #     print(s == s3)
    #     print('\n')
"""

"""

import time
import numpy as np
from collections import defaultdict

from pyscf import scf, ao2mo
from pyscf.lib import chkfile


from MajoranaOperator import MajoranaOperator
from QuarticDirac import QuarticFermion






def _quartic_maj_op_efficient(V, N, EQ_TOLERANCE=1e-8):

    V[np.absolute(V) < EQ_TOLERANCE] = 0.0
    
    maj_data = defaultdict(lambda: 0)

    # 4 index collisions
    for p in range(N):
        # p p p p
        pp_pp = V[p][p][p][p]
        
        maj_data[()] = maj_data[()] + 0.5*pp_pp 
        maj_data[(2*p, 2*p+1)] = maj_data[(2*p, 2*p+1)] + 0.5j*pp_pp    

        # 3 index collisions
        for q in range(p+1, N):
            # p p p q
            # p q q q
            pp_pq = V[p][p][p][q]
            pq_qq = V[p][q][q][q]

            maj_data[(2*p, 2*q+1)] = maj_data[(2*p, 2*q+1)] + 0.5j*(pp_pq + pq_qq)  
            maj_data[(2*p+1, 2*q)] = maj_data[(2*p+1, 2*q)] - 0.5j*(pp_pq + pq_qq)  
        
            # Double 2 index collisions
            # p p q q 
            # p q p q
            pp_qq = V[p][p][q][q]
            pq_pq = V[p][q][p][q]

            maj_data[()] = maj_data[()] + 0.5*pp_qq 
            maj_data[(2*p, 2*p+1)] = maj_data[(2*p, 2*p+1)] + 0.5j*pp_qq    
            maj_data[(2*q, 2*q+1)] = maj_data[(2*q, 2*q+1)] + 0.5j*pp_qq    

            maj_data[()] = maj_data[()] + 0.5*pq_pq 
            maj_data[(2*p, 2*p+1, 2*q, 2*q+1)] = 0.5*(pq_pq - pp_qq)    

            # 2 index collision
            for r in range(q+1, N):
                # p p q r
                pp_qr = V[p][p][q][r]
                pq_pr = V[p][q][p][r]

                maj_data[(2*q, 2*r+1)] = maj_data[(2*q, 2*r+1)] + 0.5j*pp_qr    
                maj_data[(2*q+1, 2*r)] = maj_data[(2*q+1, 2*r)] - 0.5j*pp_qr    

                maj_data[(2*p, 2*p+1, 2*q+1, 2*r)] =  0.5*(pp_qr - pq_pr)   
                maj_data[(2*p, 2*p+1, 2*q, 2*r+1)] = -0.5*(pp_qr - pq_pr)   

                # p q q r
                pq_qr = V[p][q][q][r]
                qq_pr = V[q][q][p][r]

                maj_data[(2*p, 2*r+1)] = maj_data[(2*p, 2*r+1)] + 0.5j*qq_pr    
                maj_data[(2*p+1, 2*r)] = maj_data[(2*p+1, 2*r)] - 0.5j*qq_pr    

                maj_data[(2*p, 2*q, 2*q+1, 2*r+1)] =  0.5*(pq_qr - qq_pr)   
                maj_data[(2*p+1, 2*q, 2*q+1, 2*r)] = -0.5*(pq_qr - qq_pr)   

                # p q r r
                pq_rr = V[p][q][r][r]
                pr_qr = V[p][r][q][r]

                maj_data[(2*p, 2*q+1)] = maj_data[(2*p, 2*q+1)] + 0.5j*pq_rr    
                maj_data[(2*p+1, 2*q)] = maj_data[(2*p+1, 2*q)] - 0.5j*pq_rr    

                maj_data[(2*p, 2*q+1, 2*r, 2*r+1)] =  0.5*(pr_qr - pq_rr)   
                maj_data[(2*p+1, 2*q, 2*r, 2*r+1)] = -0.5*(pr_qr - pq_rr)   

                # No collision
                for s in range(r+1, N):
                    # p q r s
                    pq_rs = V[p][q][r][s]
                    pr_qs = V[p][r][q][s]
                    qr_ps = V[q][r][p][s]

                    maj_data[(2*p+1, 2*q, 2*r, 2*s+1)] = 0.5*(pq_rs - pr_qs)    
                    maj_data[(2*p, 2*q+1, 2*r+1, 2*s)] = 0.5*(pq_rs - pr_qs)    

                    maj_data[(2*p, 2*q, 2*r+1, 2*s+1)] = 0.5*(pr_qs - qr_ps)    
                    maj_data[(2*p+1, 2*q+1, 2*r, 2*s)] = 0.5*(pr_qs - qr_ps)    

                    maj_data[(2*p, 2*q+1, 2*r, 2*s+1)] = 0.5*(qr_ps - pq_rs)    
                    maj_data[(2*p+1, 2*q, 2*r+1, 2*s)] = 0.5*(qr_ps - pq_rs)    

    return MajoranaOperator(maj_data, 2*N+1, skip_initial_ordering=True)


    
    



if __name__ == "__main__":

    chk = 'chks/h_cl_cc-pVQZ_chkfile.chk'

    t0 = time.time()

    mol = chkfile.load_mol(chk)

    t1 = time.time()
    print(f"Time to load: {t1 - t0}")

    ## TO-DO: CORRECT FOR SPIN with RHF / ROHF
    mf = scf.ROHF(mol)
    scf_result_dic = chkfile.load(chk, 'scf')
    mf.__dict__.update(scf_result_dic)

    t2 = time.time()
    print(f"Time to create mf: {t2 - t1}")

    # H1 = Tne + Vnn
    hcore = mf.get_hcore()

    t3 = time.time()
    print(f"Time to get hcore: {t3 - t2}")

    # H2 = Vee
    eri_4d = ao2mo.restore(1, mol.intor('int2e'), mol.nao_nr())
    # print(eri_4d.shape)

    MO1 = _quartic_maj_op_efficient(eri_4d, mol.nao_nr())

    # h1 = get_h1(hcore)
    h1 = None

    t4 = time.time()
    print(f"Time to get Maj Op from unique vals: {t4 - t3}")
